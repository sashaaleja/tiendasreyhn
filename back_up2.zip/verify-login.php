<?php session_start();?>
<?php
$UsernameEmail = $_POST["EmailUsername"];
$Password = $_POST["Password"];

$SQL = "SELECT * FROM usuarios WHERE Usuario = '$UsernameEmail' OR Email='$UsernameEmail'";

$Mysqli = new mysqli("localhost:3370","root","Filipenses413@","tiendasrey") or die("Error al  conectar con base de datos.");

if($resultado = $Mysqli->query($SQL)){
    while($row = $resultado->fetch_assoc()){
       $Usuario = $row["Usuario"];
       $Email = $row["Email"];
       $PasswordC = $row["Clave"];
    }

}

if($UsernameEmail == $Usuario || $Password == $PasswordC){
    $_SESSION["State"] = "Success";
    $_SESSION["EmailL"] = $Email;
    $_SESSION["UsuarioL"] = $Usuario;
    $_SESSION["Password"] = $PasswordC;
    header("location:index.php");
    if($UsernameEmail == $Email || $Password == $PasswordC){
        $_SESSION["State"] = "Success";
        $_SESSION["EmailL"] = $Email;
        $_SESSION["UsuarioL"] = $Usuario;
        $_SESSION["Password"] = $PasswordC;
        header("location:index.php");
        
    } 
}

?>